function hello()
    return [[
for i = 1, 5 do
    print(i, ": hello world")
end
    ]]
end